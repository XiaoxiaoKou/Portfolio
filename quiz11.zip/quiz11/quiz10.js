let background = document.getElementById("a");
let circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
circle.setAttribute('cx','25');
circle.setAttribute('cy','15');
circle.setAttribute('r','5');
circle.setAttribute('fill','red');
background.appendChild(circle);